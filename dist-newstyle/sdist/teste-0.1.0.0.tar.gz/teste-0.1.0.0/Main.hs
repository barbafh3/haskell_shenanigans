module Main where

import Data.Locator

main :: IO ()
main = do
  line <- getLine
  result <- fromEnglish16 line
  putStrLn "Hello, Haskell!"
